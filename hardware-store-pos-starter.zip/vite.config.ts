import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // Set VITE_BASE_PATH=/hardware-store-pos/ in GitHub Actions for project Pages URLs.
  base: process.env.VITE_BASE_PATH || '/',
});
