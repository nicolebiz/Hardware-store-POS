import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined;

export const isConfigured = Boolean(url && key && !url.includes('YOUR_PROJECT_REF') && !key.includes('YOUR_SUPABASE'));
export const supabase = isConfigured ? createClient(url!, key!, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
}) : null;

export type UserRole = 'owner' | 'admin' | 'staff';
export type Profile = { id: string; full_name: string | null; active_branch_id: string | null };
export type Branch = { id: string; name: string; code: string; organization_id: string };
export type Product = {
  id: string; sku: string; barcode: string | null; name: string; category: string | null;
  unit: string; cost_price: number; selling_price: number; reorder_level: number; active: boolean;
};
export type InventoryRow = { product_id: string; branch_id: string; quantity_on_hand: number; product?: Product };
export type CartLine = { product: Product; qty: number };

export function money(value: number) {
  return new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(value || 0);
}
export function makeSku(name: string, suffix: number) {
  const prefix = (name.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 3) || 'PRD').padEnd(3, 'X');
  return `${prefix}-${String(suffix).padStart(5, '0')}`;
}
export function makeDemoBarcode(seed: number) {
  // This is a store-internal barcode, not a GS1-issued retail GTIN.
  return `200${String(seed).padStart(9, '0')}`;
}
