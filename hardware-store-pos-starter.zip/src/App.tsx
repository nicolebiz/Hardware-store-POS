import { useEffect, useMemo, useState } from 'react';
import { supabase, isConfigured, money, makeSku, makeDemoBarcode, type Product, type CartLine, type Branch, type UserRole } from './lib';
import {
  Activity, Archive, BarChart3, Boxes, Building2, Check, ChevronDown, CircleDollarSign,
  ClipboardList, CloudOff, CreditCard, FileText, HardHat, LayoutDashboard, LogOut,
  PackagePlus, Plus, RefreshCw, Search, Settings, ShieldCheck, ShoppingCart, Truck,
  Users, X, Menu, Barcode, Wifi, WifiOff
} from 'lucide-react';

type Page = 'Dashboard' | 'POS Checkout' | 'Inventory' | 'Sales History' | 'Suppliers' | 'Customers & Credit' | 'Purchase Orders' | 'Goods Receiving' | 'Stock Transfers' | 'Supplier Payables' | 'Expenses' | 'Reports' | 'Users & Permissions' | 'Tax Settings' | 'Backup & Restore' | 'Settings';
type QueueSale = { id: string; branch_id: string; items: { product_id: string; qty: number; unit_price: number }[]; payment_method: string; created_at: string; total: number; status: 'pending' };
const nav: { label: Page; icon: typeof LayoutDashboard; group: string }[] = [
  {label:'Dashboard',icon:LayoutDashboard,group:'Overview'},
  {label:'POS Checkout',icon:ShoppingCart,group:'Sales'},
  {label:'Sales History',icon:FileText,group:'Sales'},
  {label:'Inventory',icon:Boxes,group:'Stock'},
  {label:'Suppliers',icon:Truck,group:'Stock'},
  {label:'Purchase Orders',icon:ClipboardList,group:'Stock'},
  {label:'Goods Receiving',icon:PackagePlus,group:'Stock'},
  {label:'Stock Transfers',icon:Building2,group:'Stock'},
  {label:'Customers & Credit',icon:Users,group:'Accounts'},
  {label:'Supplier Payables',icon:CreditCard,group:'Accounts'},
  {label:'Expenses',icon:CircleDollarSign,group:'Accounts'},
  {label:'Reports',icon:BarChart3,group:'Management'},
  {label:'Users & Permissions',icon:ShieldCheck,group:'Management'},
  {label:'Tax Settings',icon:Settings,group:'Management'},
  {label:'Backup & Restore',icon:Archive,group:'Management'},
  {label:'Settings',icon:Settings,group:'Management'}
];
const queueKey = 'hardware-pos-offline-sales-v1';

export default function App() {
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [page, setPage] = useState<Page>('Dashboard');
  const [mobileNav, setMobileNav] = useState(false);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [branchId, setBranchId] = useState('');
  const [role, setRole] = useState<UserRole>('staff');
  const [branchRoles, setBranchRoles] = useState<Record<string, UserRole>>({});
  const [products, setProducts] = useState<Product[]>([]);
  const [stock, setStock] = useState<Record<string, number>>({});
  const [salesCount, setSalesCount] = useState(0);
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState<CartLine[]>([]);
  const [payMethod, setPayMethod] = useState('cash');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [showProduct, setShowProduct] = useState(false);
  const [productForm, setProductForm] = useState({name:'', unit:'piece', category:'', cost_price:'0', selling_price:'0', reorder_level:'5', quantity:'0', sku:'', barcode:''});
  const [offlineQueue, setOfflineQueue] = useState<QueueSale[]>([]);
  const [online, setOnline] = useState(navigator.onLine);

  useEffect(() => {
    const saved = localStorage.getItem(queueKey);
    if (saved) try { setOfflineQueue(JSON.parse(saved)); } catch { localStorage.removeItem(queueKey); }
    const up = () => setOnline(true), down = () => setOnline(false);
    window.addEventListener('online', up); window.addEventListener('offline', down);
    if (!supabase) { setLoading(false); }
    else {
      supabase.auth.getSession().then(({data}) => { setSession(data.session); setLoading(false); });
      const {data:{subscription}} = supabase.auth.onAuthStateChange((_event, s) => { setSession(s); setLoading(false); });
      return () => { subscription.unsubscribe(); window.removeEventListener('online', up); window.removeEventListener('offline', down); };
    }
    return () => { window.removeEventListener('online', up); window.removeEventListener('offline', down); };
  }, []);

  useEffect(() => {
    localStorage.setItem(queueKey, JSON.stringify(offlineQueue));
  }, [offlineQueue]);

  useEffect(() => { if (session && supabase) void loadWorkspace(); }, [session]);

  async function loadWorkspace() {
    if (!supabase) return;
    setBusy(true);
    try {
      const {data: memberships, error: me} = await supabase.from('branch_memberships').select('role, branch_id, branches(id,name,code,organization_id)').eq('user_id', session.user.id).eq('active', true);
      if (me) throw me;
      const rows = (memberships || []) as any[];
      setBranches(rows.map(r => r.branches).filter(Boolean));
      setBranchRoles(Object.fromEntries(rows.map(r => [r.branch_id, r.role as UserRole])));
      const picked = branchId || rows[0]?.branch_id || '';
      setBranchId(picked);
      setRole(rows.find(r => r.branch_id === picked)?.role || 'staff');
      if (picked) {
        const [{data: prod, error: pe}, {data: inv, error: ie}, {count, error: se}] = await Promise.all([
          supabase.from('products').select('id,sku,barcode,name,category,unit,cost_price,selling_price,reorder_level,active').eq('active',true).order('name'),
          supabase.from('inventory').select('product_id,quantity_on_hand').eq('branch_id',picked),
          supabase.from('sales').select('*',{count:'exact',head:true}).eq('branch_id',picked)
        ]);
        if (pe) throw pe; if (ie) throw ie; if (se) throw se;
        setProducts((prod || []) as Product[]);
        setStock(Object.fromEntries((inv || []).map((x:any) => [x.product_id, Number(x.quantity_on_hand)])));
        setSalesCount(count || 0);
      }
    } catch (e:any) { setNotice(e.message || 'Could not load your workspace. Check branch membership and database setup.'); }
    finally { setBusy(false); }
  }

  async function signIn(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    setBusy(true); setLoginError('');
    const {error} = await supabase.auth.signInWithPassword({email,password});
    if (error) setLoginError(error.message);
    setBusy(false);
  }
  async function signOut() { await supabase?.auth.signOut(); setCart([]); }
  function addToCart(p: Product) {
    setCart(current => {
      const existing = current.find(x => x.product.id === p.id);
      if (existing) return current.map(x => x.product.id === p.id ? {...x, qty: Math.min(x.qty + 1, stock[p.id] ?? 0)} : x);
      if ((stock[p.id] ?? 0) < 1) { setNotice('No available stock for this product in the selected branch.'); return current; }
      return [...current, {product:p,qty:1}];
    });
  }
  const filtered = useMemo(() => products.filter(p => `${p.name} ${p.sku} ${p.barcode || ''}`.toLowerCase().includes(search.toLowerCase())), [products,search]);
  const cartTotal = cart.reduce((s,l) => s + l.qty * Number(l.product.selling_price), 0);

  async function createProduct(e: React.FormEvent) {
    e.preventDefault(); if (!supabase || !branchId) return;
    setBusy(true); setNotice('');
    try {
      const {data: next, error: ne} = await supabase.from('products').select('sku').order('created_at',{ascending:false}).limit(1);
      if (ne) throw ne;
      const seq = (products.length + 1);
      const sku = productForm.sku || makeSku(productForm.name, seq);
      const barcode = productForm.barcode || makeDemoBarcode(Date.now() % 1000000000);
      const {data:p,error} = await supabase.from('products').insert({
        organization_id: branches.find(b=>b.id===branchId)?.organization_id, name:productForm.name.trim(), sku, barcode, unit:productForm.unit, category:productForm.category || null,
        cost_price:Number(productForm.cost_price), selling_price:Number(productForm.selling_price), reorder_level:Number(productForm.reorder_level)
      }).select().single();
      if (error) throw error;
      const {error: invErr} = await supabase.from('inventory').insert({product_id:p.id,branch_id:branchId,quantity_on_hand:Number(productForm.quantity)});
      if (invErr) throw invErr;
      setShowProduct(false); setProductForm({name:'',unit:'piece',category:'',cost_price:'0',selling_price:'0',reorder_level:'5',quantity:'0',sku:'',barcode:''});
      await loadWorkspace(); setNotice('Product saved.');
    } catch (e:any) { setNotice(e.message || 'Product could not be saved.'); }
    finally { setBusy(false); }
  }

  async function checkout() {
    if (!supabase || !branchId || cart.length === 0) return;
    setBusy(true); setNotice('');
    const clientOrderId = crypto.randomUUID();
    const payload = {p_branch_id:branchId,p_client_order_id:clientOrderId,p_payment_method:payMethod,p_items:cart.map(l=>({product_id:l.product.id,quantity:l.qty,unit_price:Number(l.product.selling_price)}))};
    try {
      if (!online) throw new Error('OFFLINE');
      const {data,error} = await supabase.rpc('checkout_sale',payload);
      if (error) throw error;
      setCart([]); await loadWorkspace(); setNotice(`Sale saved successfully. Receipt reference: ${String(data).slice(0,8).toUpperCase()}`);
    } catch (e:any) {
      if (!online || e.message === 'OFFLINE' || e.message?.includes('fetch')) {
        const sale: QueueSale = {id:clientOrderId,branch_id:branchId,items:cart.map(l=>({product_id:l.product.id,qty:l.qty,unit_price:Number(l.product.selling_price)})),payment_method:payMethod,created_at:new Date().toISOString(),total:cartTotal,status:'pending'};
        setOfflineQueue(q=>[...q,sale]); setCart([]); setNotice('Saved to this device as a pending offline sale. It is not yet included in server stock or reports.');
      } else setNotice(e.message || 'Checkout failed. No sale was confirmed.');
    } finally { setBusy(false); }
  }

  async function syncQueue() {
    if (!supabase || !online || !branchId) return;
    setBusy(true); let synced = 0;
    for (const sale of offlineQueue) {
      if (sale.branch_id !== branchId) continue;
      const {error} = await supabase.rpc('checkout_sale',{p_branch_id:sale.branch_id,p_client_order_id:sale.id,p_payment_method:sale.payment_method,p_items:sale.items.map(i=>({product_id:i.product_id,quantity:i.qty,unit_price:i.unit_price}))});
      if (!error) { setOfflineQueue(q=>q.filter(s=>s.id!==sale.id)); synced++; }
      else { setNotice(`Sync paused: ${error.message}. Pending sale retained on this device.`); break; }
    }
    await loadWorkspace(); if (synced) setNotice(`${synced} offline sale(s) synced. Review pending items before retrying any failed transaction.`); setBusy(false);
  }

  if (loading) return <div className="center-screen"><div className="loader"/>Loading Hardware POS…</div>;
  if (!isConfigured) return <SetupScreen />;
  if (!session) return <div className="auth-shell"><div className="auth-card"><div className="brand-mark"><HardHat size={28}/></div><p className="eyebrow">HARDWARE STORE MANAGEMENT</p><h1>Welcome back</h1><p className="muted">Sign in to your store workspace.</p><form onSubmit={signIn} className="form-stack"><label>Email<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} autoComplete="username"/></label><label>Password<input type="password" required value={password} onChange={e=>setPassword(e.target.value)} autoComplete="current-password"/></label>{loginError && <p className="error">{loginError}</p>}<button className="primary full" disabled={busy}>{busy?'Signing in…':'Sign in securely'}</button></form><p className="tiny muted">Accounts must be created by your system owner in Supabase Auth and assigned to a branch.</p></div></div>;

  return <div className="app-shell">
    {mobileNav && <button className="scrim" aria-label="Close menu" onClick={()=>setMobileNav(false)}/>}
    <aside className={`sidebar ${mobileNav?'sidebar-open':''}`}>
      <div className="brand"><div className="brand-mark"><HardHat size={23}/></div><div><strong>Hardware POS</strong><small>STORE OPERATIONS</small></div><button className="icon-button mobile-only" onClick={()=>setMobileNav(false)}><X size={18}/></button></div>
      <div className="store-picker"><span className="tiny muted">ACTIVE BRANCH</span><select value={branchId} onChange={e=>{setBranchId(e.target.value);setRole(branchRoles[e.target.value] || 'staff');}}>{branches.map(b=><option key={b.id} value={b.id}>{b.name}</option>)}</select></div>
      <nav>{['Overview','Sales','Stock','Accounts','Management'].map(group=><div className="nav-group" key={group}><div className="nav-label">{group}</div>{nav.filter(n=>n.group===group).map(item=>{const Icon=item.icon;return <button key={item.label} className={`nav-item ${page===item.label?'active':''}`} onClick={()=>{setPage(item.label);setMobileNav(false);}}><Icon size={17}/><span>{item.label}</span>{item.label==='POS Checkout'&&<span className="nav-dot"/>}</button>})}</div>)}</nav>
      <div className="sidebar-bottom"><div className="connection"><span className={`status-dot ${online?'':'offline'}`}/>{online?'Online':'Offline'} <span className="tiny muted">{offlineQueue.length?`· ${offlineQueue.length} pending`:''}</span></div><div className="user-card"><div className="avatar">{session.user.email?.[0]?.toUpperCase()||'U'}</div><div className="user-info"><strong>{session.user.email}</strong><small>{role.toUpperCase()}</small></div><button className="icon-button" title="Sign out" onClick={signOut}><LogOut size={17}/></button></div></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><div className="topbar-left"><button className="icon-button mobile-only" onClick={()=>setMobileNav(true)}><Menu/></button><div><p className="eyebrow">STORE OPERATIONS / {page.toUpperCase()}</p><h1>{page}</h1></div></div><div className="top-actions"><div className={`network-pill ${online?'':'network-off'}`}>{online?<Wifi size={15}/>:<WifiOff size={15}/>}<span>{online?'Connected':'Offline mode'}</span></div><button className="icon-button" title="Refresh data" onClick={()=>void loadWorkspace()}><RefreshCw size={17}/></button><div className="avatar">{session.user.email?.[0]?.toUpperCase()||'U'}</div></div></header>
      {notice && <div className="notice"><Activity size={16}/><span>{notice}</span><button className="icon-button" onClick={()=>setNotice('')}><X size={16}/></button></div>}
      {offlineQueue.length>0 && <div className="sync-banner"><CloudOff size={18}/><div><strong>{offlineQueue.length} pending offline sale(s)</strong><p>Pending sales are stored only on this device until synced. Confirm each one before retrying if the result is uncertain.</p></div><button className="secondary" disabled={!online||busy} onClick={()=>void syncQueue()}><RefreshCw size={15}/> Sync queue</button></div>}
      {page==='Dashboard' && <Dashboard products={products} stock={stock} salesCount={salesCount} role={role} queue={offlineQueue.length} onNavigate={setPage}/>}
      {page==='Inventory' && <section className="panel"><div className="panel-heading"><div><h2>Inventory</h2><p className="muted">Branch stock, cost, price, SKU and barcode lookup.</p></div><button className="primary" onClick={()=>setShowProduct(true)}><Plus size={16}/> Add product</button></div><div className="toolbar"><div className="searchbox"><Search size={17}/><input placeholder="Search product, SKU or barcode…" value={search} onChange={e=>setSearch(e.target.value)}/></div><span className="muted tiny">{filtered.length} products</span></div><div className="table-wrap"><table><thead><tr><th>Product</th><th>SKU / Barcode</th><th>Unit</th><th>On hand</th><th>Cost</th><th>Selling price</th><th>Status</th></tr></thead><tbody>{filtered.map(p=><tr key={p.id}><td><strong>{p.name}</strong><small className="cell-sub">{p.category||'Uncategorized'}</small></td><td><span className="mono">{p.sku}</span><small className="cell-sub">{p.barcode||'—'}</small></td><td>{p.unit}</td><td><strong>{stock[p.id]??0}</strong></td><td>{money(Number(p.cost_price))}</td><td>{money(Number(p.selling_price))}</td><td><span className={`badge ${(stock[p.id]??0)<=Number(p.reorder_level)?'warning':'success'}`}>{(stock[p.id]??0)<=Number(p.reorder_level)?'Low stock':'In stock'}</span></td></tr>)}</tbody></table>{filtered.length===0&&<div className="empty-state">No products found. Add a product or change your search.</div>}</div></section>}
      {page==='POS Checkout' && <div className="pos-layout"><section className="panel product-browser"><div className="panel-heading"><div><h2>Find products</h2><p className="muted">Search by name, SKU or barcode. USB scanners usually type into this field.</p></div></div><div className="searchbox"><Search size={17}/><input autoFocus placeholder="Scan barcode or search products…" value={search} onChange={e=>setSearch(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&filtered.length===1){addToCart(filtered[0]);setSearch('');}}}/></div><div className="product-grid">{filtered.map(p=><button className="product-tile" key={p.id} disabled={(stock[p.id]??0)<1} onClick={()=>addToCart(p)}><span className="product-icon"><Boxes size={20}/></span><strong>{p.name}</strong><small>{p.sku} · {stock[p.id]??0} {p.unit}</small><b>{money(Number(p.selling_price))}</b></button>)}</div></section><section className="panel cart-panel"><div className="panel-heading"><div><h2>Current sale</h2><p className="muted">{cart.length} line item(s)</p></div><button className="icon-button" onClick={()=>setCart([])} title="Clear cart"><X size={17}/></button></div><div className="cart-lines">{cart.map(line=><div className="cart-line" key={line.product.id}><div className="cart-line-info"><strong>{line.product.name}</strong><small>{money(Number(line.product.selling_price))} each</small></div><div className="qty-controls"><button onClick={()=>setCart(c=>c.map(x=>x.product.id===line.product.id?{...x,qty:Math.max(1,x.qty-1)}:x))}>−</button><span>{line.qty}</span><button disabled={line.qty >= (stock[line.product.id]??0)} onClick={()=>setCart(c=>c.map(x=>x.product.id===line.product.id?{...x,qty:x.qty+1}:x))}>+</button></div><strong>{money(line.qty*Number(line.product.selling_price))}</strong><button className="icon-button" onClick={()=>setCart(c=>c.filter(x=>x.product.id!==line.product.id))}><X size={15}/></button></div>)}{cart.length===0&&<div className="empty-state">Your cart is empty. Search or scan a product to begin.</div>}</div><div className="checkout-summary"><div><span>Subtotal</span><strong>{money(cartTotal)}</strong></div><div><span>Tax</span><span>Configured in Tax Settings (next phase)</span></div><div className="grand-total"><span>Total due</span><strong>{money(cartTotal)}</strong></div><label>Payment method<select value={payMethod} onChange={e=>setPayMethod(e.target.value)}><option value="cash">Cash</option><option value="gcash">GCash</option><option value="maya">Maya</option><option value="bank_transfer">Bank transfer</option><option value="grabpay">GrabPay</option><option value="split">Split payment (next phase)</option><option value="customer_credit">Customer credit / utang</option></select></label><button className="primary full checkout-button" disabled={!cart.length||busy||!branchId} onClick={()=>void checkout()}><ShoppingCart size={17}/>{busy?'Processing…':online?'Complete sale':'Save offline sale'} · {money(cartTotal)}</button><p className="tiny muted">Server checkout is atomic and idempotent. Offline sales stay pending until sync succeeds.</p></div></section></div>}
      {page!=='Dashboard'&&page!=='Inventory'&&page!=='POS Checkout'&&<ModulePlaceholder page={page} role={role} />}
      <footer className="footer"><span>Hardware POS · Early build</span><span>{branches.find(b=>b.id===branchId)?.name||'No branch selected'} · {online?'Online':'Offline'}</span></footer>
    </main>
    {showProduct && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setShowProduct(false);}}><form className="modal" onSubmit={createProduct}><div className="modal-heading"><div><h2>Add inventory item</h2><p className="muted">Product and starting stock are saved to the selected branch.</p></div><button type="button" className="icon-button" onClick={()=>setShowProduct(false)}><X/></button></div><label>Product name<input required value={productForm.name} onChange={e=>setProductForm({...productForm,name:e.target.value,sku:makeSku(e.target.value,products.length+1),barcode:makeDemoBarcode(products.length+1)})}/></label><div className="form-grid"><label>SKU<input required value={productForm.sku} onChange={e=>setProductForm({...productForm,sku:e.target.value})}/></label><label>Internal barcode<input value={productForm.barcode} onChange={e=>setProductForm({...productForm,barcode:e.target.value})}/></label><label>Unit<select value={productForm.unit} onChange={e=>setProductForm({...productForm,unit:e.target.value})}>{['piece','box','pack','bag','meter','kilogram','liter','roll','sheet','set','pair','length','sack'].map(x=><option key={x}>{x}</option>)}</select></label><label>Category<input value={productForm.category} onChange={e=>setProductForm({...productForm,category:e.target.value})} placeholder="e.g. Cement"/></label><label>Cost price (PHP)<input type="number" min="0" step="0.01" required value={productForm.cost_price} onChange={e=>setProductForm({...productForm,cost_price:e.target.value})}/></label><label>Selling price (PHP)<input type="number" min="0" step="0.01" required value={productForm.selling_price} onChange={e=>setProductForm({...productForm,selling_price:e.target.value})}/></label><label>Starting stock<input type="number" min="0" step="0.001" required value={productForm.quantity} onChange={e=>setProductForm({...productForm,quantity:e.target.value})}/></label><label>Reorder level<input type="number" min="0" step="0.001" required value={productForm.reorder_level} onChange={e=>setProductForm({...productForm,reorder_level:e.target.value})}/></label></div><div className="modal-actions"><button type="button" className="secondary" onClick={()=>setShowProduct(false)}>Cancel</button><button className="primary" disabled={busy}><Check size={16}/> Save product</button></div><p className="tiny muted">Generated barcodes here are internal store labels, not registered GS1 GTINs.</p></form></div>}
  </div>;
}

function SetupScreen() {
  return <div className="setup-shell"><div className="setup-card"><div className="brand-mark"><HardHat size={28}/></div><p className="eyebrow">HARDWARE STORE POS</p><h1>Connect your store database</h1><p className="muted">This application is ready for a Supabase project. Add your project URL and publishable key to the local <code>.env</code> file, then restart the development server.</p><div className="setup-steps"><div><span>1</span><p>Create a project at <a href="https://supabase.com/dashboard" target="_blank" rel="noreferrer">Supabase Dashboard</a>.</p></div><div><span>2</span><p>Run <code>supabase/migrations/001_initial_schema.sql</code> in the Supabase SQL Editor.</p></div><div><span>3</span><p>Copy the project URL and publishable key into <code>.env</code>.</p></div><div><span>4</span><p>Create your first Auth user and follow <code>README.md</code> to initialize the owner and branch.</p></div></div><pre>VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co{"\n"}VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY</pre><p className="tiny muted">Never put a Supabase service-role/secret key in this frontend.</p></div></div>;
}
function Dashboard({products,stock,salesCount,role,queue,onNavigate}:{products:Product[];stock:Record<string,number>;salesCount:number;role:UserRole;queue:number;onNavigate:(p:Page)=>void}) {
  const low = products.filter(p=>(stock[p.id]??0)<=Number(p.reorder_level));
  return <><div className="welcome-row"><div><h2>Good day 👋</h2><p className="muted">Here's your store's current operational snapshot.</p></div><span className="badge info">{role.toUpperCase()} ACCESS</span></div><div className="metric-grid"><Metric icon={Boxes} label="Active products" value={String(products.length)} sub="Across selected branch"/><Metric icon={ShoppingCart} label="Recorded sales" value={String(salesCount)} sub="Transaction count"/><Metric icon={Activity} label="Low-stock items" value={String(low.length)} sub="At or below reorder level"/><Metric icon={CloudOff} label="Offline queue" value={String(queue)} sub="Pending on this device"/></div><div className="dashboard-grid"><section className="panel"><div className="panel-heading"><div><h2>Stock needing attention</h2><p className="muted">Products at or below their reorder level.</p></div><button className="text-button" onClick={()=>onNavigate('Inventory')}>View inventory →</button></div>{low.slice(0,6).map(p=><div className="attention-row" key={p.id}><div className="mini-icon"><Boxes size={17}/></div><div className="attention-info"><strong>{p.name}</strong><small>{p.sku} · reorder at {p.reorder_level} {p.unit}</small></div><span className="badge warning">{stock[p.id]??0} left</span></div>)}{!low.length&&<div className="empty-state">No low-stock items for the selected branch.</div>}</section><section className="panel"><div className="panel-heading"><div><h2>Quick actions</h2><p className="muted">Common store workflows.</p></div></div><div className="quick-actions"><button onClick={()=>onNavigate('POS Checkout')}><ShoppingCart/><span><strong>New sale</strong><small>Start checkout</small></span><ChevronDown className="arrow"/></button><button onClick={()=>onNavigate('Inventory')}><PackagePlus/><span><strong>Add inventory</strong><small>Manage products and stock</small></span><ChevronDown className="arrow"/></button><button onClick={()=>onNavigate('Purchase Orders')}><Truck/><span><strong>Order stock</strong><small>Purchase orders</small></span><ChevronDown className="arrow"/></button><button onClick={()=>onNavigate('Reports')}><BarChart3/><span><strong>View reports</strong><small>Sales and inventory</small></span><ChevronDown className="arrow"/></button></div></section></div></>;
}
function Metric({icon:Icon,label,value,sub}:{icon:typeof Boxes;label:string;value:string;sub:string}){return <div className="metric-card"><div className="metric-top"><span>{label}</span><span className="metric-icon"><Icon size={18}/></span></div><strong className="metric-value">{value}</strong><small>{sub}</small></div>}
function ModulePlaceholder({page,role}:{page:Page;role:UserRole}) {
  const desc:Record<string,string> = {
    'Sales History':'Search receipts, review line items, reprint receipts and track void/refund approvals.',
    'Suppliers':'Maintain supplier contacts, supplied products, pricing, purchase history and payment terms.',
    'Customers & Credit':'Customer profiles, credit limits, partial payments, statements and overdue aging.',
    'Purchase Orders':'Draft, approve and track purchase orders to suppliers.',
    'Goods Receiving':'Receive supplier deliveries and update stock with a traceable receiving record.',
    'Stock Transfers':'Transfer stock between branches with dispatch and receiving confirmation.',
    'Supplier Payables':'Track supplier invoices, due dates, partial/full payments and overdue balances.',
    'Expenses':'Record operating expenses and recurring bills without double-counting stock purchases.',
    'Reports':'Branch-level and consolidated sales, margin, stock movement and account aging reports.',
    'Users & Permissions':'Manage Owner, Admin and Staff roles, branch memberships and access rules.',
    'Tax Settings':'Configure tax on/off, rate, inclusive/exclusive pricing and invoice mode; no BIR integration.',
    'Backup & Restore':'Plan database exports, restore drills, and owner-only backup controls.',
    'Settings':'Store details, invoice numbering, payment methods, units, receipt and device settings.'
  };
  return <section className="panel module-panel"><div className="module-icon"><ClipboardList size={28}/></div><span className="badge info">MODULE FOUNDATION</span><h2>{page}</h2><p className="muted">{desc[page]}</p><div className="module-status"><Activity size={17}/><div><strong>Module planned; workflow not yet implemented</strong><small>This initial build focuses on secure project wiring, inventory, and checkout. This module is not available for real store operations yet.</small></div></div><p className="tiny muted">Signed-in role: {role}. Access must also be enforced by database policies—not just by hiding buttons.</p></section>;
}
