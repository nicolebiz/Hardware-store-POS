# Hardware Store POS — starter application

This repository is the foundation of a real multi-branch POS application, not a static HTML mockup. It includes a React + TypeScript frontend, Supabase Auth integration, a Postgres schema with branch memberships and RLS, a server-side atomic/idempotent checkout RPC, inventory and barcode/SKU search, and a local pending-sale queue for offline interruptions.

## Current implementation status

Implemented in this starter:
- Email/password sign-in using Supabase Auth.
- Branch list based on active branch memberships.
- Product catalog, SKU/barcode lookup, stock counts and low-stock indicators.
- Product creation and starting branch stock.
- Checkout with server-side stock validation/decrement, sale items, payment record, stock movement, audit log, and idempotency key.
- A local pending queue for offline sales; queued sales remain explicitly pending until server sync.
- PWA manifest; responsive layout for mobile and desktop.
- Database foundations for customers, suppliers, purchasing, receiving, transfers, customer/supplier ledgers, expenses, employees, attendance, payroll and tax settings.

Not yet production-ready:
- The remaining modules are navigation foundations, not implemented workflows.
- Offline sales are stored in browser localStorage (not encrypted) and conflict handling is basic. Do not treat them as guaranteed durable records or allow several devices to share one offline till without a device/shift protocol.
- Tax calculation, invoice/receipt printing, refunds/void approvals, split payments, unit conversions, supplier/customer ledger workflows, payroll calculations, backups/restore and detailed reports still need implementation and tests.
- RLS policies need a security review and automated allow/deny tests before real data. Never skip staging tests.
- The included barcode is an internal code, not a GS1-issued retail GTIN.
- No BIR integration is included.

## Requirements
- Node.js 20+ and npm
- A new Supabase project
- GitHub repository
- Recommended: separate staging and production Supabase projects

## Local setup
1. Create a Supabase project at https://supabase.com/dashboard.
2. In the Supabase SQL Editor, run `supabase/migrations/001_initial_schema.sql` in a new project.
3. In Authentication > Users, create your first owner user (email/password).
4. In SQL Editor, run the following setup SQL, replacing values. Use the UUID of the Auth user created in step 3. Store credentials securely.

```sql
-- Replace all three example values before running.
with new_org as (
  insert into public.organizations(name) values ('My Hardware Store') returning id
), new_branch as (
  insert into public.branches(organization_id,name,code)
  select id, 'Main Branch', 'MAIN' from new_org returning id, organization_id
)
insert into public.branch_memberships(user_id,branch_id,role)
select 'PASTE_AUTH_USER_UUID_HERE'::uuid, id, 'owner'::public.app_role from new_branch;

insert into public.profiles(id,full_name)
values ('PASTE_AUTH_USER_UUID_HERE'::uuid, 'Store Owner')
on conflict (id) do update set full_name=excluded.full_name;

insert into public.store_settings(organization_id)
select id from public.organizations where name='My Hardware Store'
on conflict (organization_id) do nothing;
```

5. Copy `.env.example` to `.env` and set `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` from Project Settings > API Keys. Use the publishable key only; never use the `service_role`/secret key in frontend code.
6. Install and run:

```bash
npm install
npm run dev
```

7. Visit the local URL printed by Vite.

## GitHub deployment
1. Create a GitHub repository and upload/commit all project files (including the migration). Never commit `.env`.
2. In repository **Settings > Pages**, set **Build and deployment > Source** to **GitHub Actions**.
3. Under **Settings > Secrets and variables > Actions > Variables**, add:
   - `VITE_SUPABASE_URL` = your Supabase project URL
   - `VITE_SUPABASE_PUBLISHABLE_KEY` = your Supabase publishable key
4. Push to `main`. The included `.github/workflows/deploy-pages.yml` builds and publishes the frontend.
5. Your website URL will be `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

The publishable key is designed for frontend use, but the database must be protected by correct RLS. Never put a Supabase service-role/secret key in repository variables, frontend code, or browser builds. GitHub Pages hosts only the frontend, not the database/backend.

## Before real store use
1. Review and test every RLS policy with at least two organizations and multiple branches.
2. Add automated SQL tests for allowed and denied operations; validate cross-branch and cross-organization access is impossible.
3. Test checkout concurrency, repeated idempotency keys, insufficient stock, and offline conflict recovery.
4. Implement approval flows for refunds/voids and role-specific permissions.
5. Implement verified receipt/invoice printing, tax settings and rounding, and backup/restore drills.
6. Set up backups, MFA, account recovery, monitoring and a separate staging project.
7. Have a qualified developer/security reviewer inspect the schema, RPC, policies and deployment configuration before storing real customer, employee or financial data.

## Architecture
- Frontend: React, TypeScript, Vite
- Auth: Supabase Auth
- Database: Supabase Postgres
- Authorization: branch membership + database RLS; UI role checks are not a security boundary
- Checkout: `checkout_sale` RPC runs transactionally on the server
- Offline: browser queue is a temporary holding area; server-side idempotency reduces duplicate risk during sync
