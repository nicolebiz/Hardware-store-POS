-- Hardware Store POS initial schema
-- Apply only to a NEW Supabase project. Test in staging before production.
create extension if not exists pgcrypto;

create type public.app_role as enum ('owner','admin','staff');
create type public.sale_status as enum ('completed','voided','refunded','partially_refunded');
create type public.payment_method as enum ('cash','gcash','maya','grabpay','bank_transfer','card','customer_credit','split','other');

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  currency text not null default 'PHP',
  timezone text not null default 'Asia/Manila',
  created_at timestamptz not null default now()
);
create table public.branches (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  code text not null,
  address text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(organization_id, code)
);
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  active_branch_id uuid references public.branches(id),
  created_at timestamptz not null default now()
);
create table public.branch_memberships (
  user_id uuid not null references auth.users(id) on delete cascade,
  branch_id uuid not null references public.branches(id) on delete cascade,
  role public.app_role not null default 'staff',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  primary key(user_id, branch_id)
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  sku text not null,
  barcode text,
  name text not null,
  category text,
  unit text not null default 'piece',
  cost_price numeric(14,2) not null default 0 check(cost_price >= 0),
  selling_price numeric(14,2) not null default 0 check(selling_price >= 0),
  reorder_level numeric(14,3) not null default 0 check(reorder_level >= 0),
  active boolean not null default true,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(organization_id, sku)
);
create unique index products_org_barcode_unique on public.products(organization_id, barcode) where barcode is not null and barcode <> '';
create table public.inventory (
  branch_id uuid not null references public.branches(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  quantity_on_hand numeric(14,3) not null default 0,
  updated_at timestamptz not null default now(),
  primary key(branch_id, product_id)
);
create table public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  product_id uuid not null references public.products(id),
  movement_type text not null check(movement_type in ('opening','sale','refund','receiving','adjustment','transfer_out','transfer_in','damage')),
  quantity_delta numeric(14,3) not null,
  reference_type text,
  reference_id uuid,
  reason text,
  actor_id uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  phone text,
  email text,
  address text,
  credit_limit numeric(14,2) not null default 0 check(credit_limit >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  contact_person text,
  phone text,
  email text,
  address text,
  payment_terms_days integer not null default 0 check(payment_terms_days >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.sales (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  receipt_number bigint generated always as identity,
  client_order_id uuid not null,
  status public.sale_status not null default 'completed',
  customer_id uuid references public.customers(id),
  subtotal numeric(14,2) not null check(subtotal >= 0),
  tax_amount numeric(14,2) not null default 0 check(tax_amount >= 0),
  total numeric(14,2) not null check(total >= 0),
  payment_method public.payment_method not null,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique(branch_id, client_order_id),
  unique(branch_id, receipt_number)
);
create table public.sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete restrict,
  product_id uuid not null references public.products(id),
  sku_snapshot text not null,
  name_snapshot text not null,
  unit_snapshot text not null,
  quantity numeric(14,3) not null check(quantity > 0),
  unit_price numeric(14,2) not null check(unit_price >= 0),
  unit_cost numeric(14,2) not null check(unit_cost >= 0),
  line_total numeric(14,2) generated always as (round(quantity * unit_price, 2)) stored
);
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  sale_id uuid references public.sales(id),
  customer_id uuid references public.customers(id),
  supplier_id uuid references public.suppliers(id),
  direction text not null check(direction in ('incoming','outgoing')),
  method public.payment_method not null,
  amount numeric(14,2) not null check(amount > 0),
  reference_id text,
  status text not null default 'recorded' check(status in ('pending','recorded','verified','reversed')),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check ((sale_id is not null)::int + (customer_id is not null)::int + (supplier_id is not null)::int <= 1)
);
create table public.audit_logs (
  id bigint generated always as identity primary key,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  branch_id uuid references public.branches(id),
  actor_id uuid references auth.users(id),
  action text not null,
  entity_type text not null,
  entity_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Follow-on module foundations: financial balances are ledger-driven rather than manually overwritten.
create table public.customer_ledger (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  customer_id uuid not null references public.customers(id),
  sale_id uuid references public.sales(id),
  payment_id uuid references public.payments(id),
  entry_type text not null check(entry_type in ('charge','payment','adjustment','refund')),
  amount numeric(14,2) not null check(amount >= 0),
  due_date date,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create table public.purchase_orders (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  supplier_id uuid not null references public.suppliers(id),
  po_number text not null,
  status text not null default 'draft' check(status in ('draft','submitted','approved','partially_received','received','cancelled')),
  expected_at date,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique(branch_id, po_number)
);
create table public.purchase_order_items (
  id uuid primary key default gen_random_uuid(),
  purchase_order_id uuid not null references public.purchase_orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity_ordered numeric(14,3) not null check(quantity_ordered > 0),
  unit_cost numeric(14,2) not null check(unit_cost >= 0),
  quantity_received numeric(14,3) not null default 0 check(quantity_received >= 0)
);
create table public.goods_receipts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  supplier_id uuid not null references public.suppliers(id),
  purchase_order_id uuid references public.purchase_orders(id),
  supplier_invoice_number text,
  received_at timestamptz not null default now(),
  received_by uuid references auth.users(id),
  notes text
);
create table public.goods_receipt_items (
  id uuid primary key default gen_random_uuid(),
  goods_receipt_id uuid not null references public.goods_receipts(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity numeric(14,3) not null check(quantity > 0),
  unit_cost numeric(14,2) not null check(unit_cost >= 0)
);
create table public.supplier_ledger (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  supplier_id uuid not null references public.suppliers(id),
  goods_receipt_id uuid references public.goods_receipts(id),
  payment_id uuid references public.payments(id),
  entry_type text not null check(entry_type in ('bill','payment','adjustment','credit')),
  amount numeric(14,2) not null check(amount >= 0),
  due_date date,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create table public.stock_transfers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  from_branch_id uuid not null references public.branches(id),
  to_branch_id uuid not null references public.branches(id),
  status text not null default 'draft' check(status in ('draft','dispatched','received','cancelled')),
  dispatched_at timestamptz,
  received_at timestamptz,
  created_by uuid references auth.users(id),
  received_by uuid references auth.users(id),
  notes text,
  check(from_branch_id <> to_branch_id)
);
create table public.stock_transfer_items (
  id uuid primary key default gen_random_uuid(),
  transfer_id uuid not null references public.stock_transfers(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity numeric(14,3) not null check(quantity > 0)
);
create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  category text not null,
  description text not null,
  amount numeric(14,2) not null check(amount > 0),
  status text not null default 'paid' check(status in ('pending','paid','cancelled')),
  expense_date date not null default current_date,
  recurring boolean not null default false,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create table public.employees (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  auth_user_id uuid references auth.users(id),
  employee_code text not null,
  full_name text not null,
  position text,
  hourly_rate numeric(14,2) not null default 0 check(hourly_rate >= 0),
  monthly_salary numeric(14,2) not null default 0 check(monthly_salary >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(branch_id, employee_code)
);
create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.employees(id),
  clock_in timestamptz not null,
  clock_out timestamptz,
  notes text,
  created_by uuid references auth.users(id),
  check(clock_out is null or clock_out >= clock_in)
);
create table public.payroll_runs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  period_start date not null,
  period_end date not null,
  status text not null default 'draft' check(status in ('draft','approved','paid','cancelled')),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check(period_end >= period_start)
);
create table public.payroll_items (
  id uuid primary key default gen_random_uuid(),
  payroll_run_id uuid not null references public.payroll_runs(id) on delete cascade,
  employee_id uuid not null references public.employees(id),
  gross_pay numeric(14,2) not null check(gross_pay >= 0),
  deductions numeric(14,2) not null default 0 check(deductions >= 0),
  net_pay numeric(14,2) generated always as (gross_pay - deductions) stored
);
create table public.store_settings (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  tax_enabled boolean not null default false,
  tax_rate numeric(7,5) not null default 0 check(tax_rate >= 0 and tax_rate <= 1),
  tax_inclusive boolean not null default false,
  invoice_mode text not null default 'with_tax' check(invoice_mode in ('with_tax','without_tax')),
  receipt_prefix text not null default 'INV',
  updated_at timestamptz not null default now()
);

create index inventory_branch_idx on public.inventory(branch_id);
create index sales_branch_created_idx on public.sales(branch_id, created_at desc);
create index stock_movements_branch_created_idx on public.stock_movements(branch_id, created_at desc);
create index customer_ledger_due_idx on public.customer_ledger(customer_id, due_date);
create index supplier_ledger_due_idx on public.supplier_ledger(supplier_id, due_date);

-- Security helpers: role/membership checks are evaluated in the database.
create or replace function public.is_branch_member(p_branch_id uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.branch_memberships bm
    where bm.branch_id = p_branch_id and bm.user_id = (select auth.uid()) and bm.active
  );
$$;
create or replace function public.has_branch_role(p_branch_id uuid, p_roles public.app_role[])
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.branch_memberships bm
    where bm.branch_id = p_branch_id and bm.user_id = (select auth.uid())
      and bm.active and bm.role = any(p_roles)
  );
$$;
create or replace function public.organization_for_branch(p_branch_id uuid)
returns uuid language sql stable security definer set search_path = '' as $$
  select b.organization_id from public.branches b where b.id = p_branch_id;
$$;
revoke all on function public.is_branch_member(uuid) from public;
revoke all on function public.has_branch_role(uuid, public.app_role[]) from public;
revoke all on function public.organization_for_branch(uuid) from public;
grant execute on function public.is_branch_member(uuid) to authenticated;
grant execute on function public.has_branch_role(uuid, public.app_role[]) to authenticated;
grant execute on function public.organization_for_branch(uuid) to authenticated;

-- RLS enabled on every business table. Access rules are deliberately restrictive.
do $$
declare t text;
begin
  foreach t in array array[
    'organizations','branches','profiles','branch_memberships','products','inventory','stock_movements',
    'customers','suppliers','sales','sale_items','payments','audit_logs','customer_ledger',
    'purchase_orders','purchase_order_items','goods_receipts','goods_receipt_items','supplier_ledger',
    'stock_transfers','stock_transfer_items','expenses','employees','attendance','payroll_runs','payroll_items','store_settings'
  ] loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;

-- Membership is branch-scoped; owner/admin may manage operational data, staff may sell and read operational data.
create policy "organizations_read_member" on public.organizations for select to authenticated
using (exists(select 1 from public.branches b where b.organization_id=organizations.id and public.is_branch_member(b.id)));
create policy "branches_read_member" on public.branches for select to authenticated
using (public.is_branch_member(id));
create policy "profiles_read_self" on public.profiles for select to authenticated using (id=(select auth.uid()));
create policy "profiles_update_self" on public.profiles for update to authenticated using (id=(select auth.uid())) with check (id=(select auth.uid()));
create policy "memberships_read_self_or_admin" on public.branch_memberships for select to authenticated
using (user_id=(select auth.uid()) or public.has_branch_role(branch_id,array['owner','admin']::public.app_role[]));
create policy "products_read_member" on public.products for select to authenticated
using (exists(select 1 from public.branches b where b.organization_id=products.organization_id and public.is_branch_member(b.id)));
create policy "products_insert_admin" on public.products for insert to authenticated
with check (public.has_branch_role((select bm.branch_id from public.branch_memberships bm join public.branches b on b.id=bm.branch_id where b.organization_id=products.organization_id and bm.user_id=(select auth.uid()) and bm.active limit 1),array['owner','admin']::public.app_role[]));
create policy "products_update_admin" on public.products for update to authenticated
using (exists(select 1 from public.branches b where b.organization_id=products.organization_id and public.has_branch_role(b.id,array['owner','admin']::public.app_role[])))
with check (exists(select 1 from public.branches b where b.organization_id=products.organization_id and public.has_branch_role(b.id,array['owner','admin']::public.app_role[])));
create policy "inventory_read_member" on public.inventory for select to authenticated using (public.is_branch_member(branch_id));
create policy "inventory_write_admin" on public.inventory for all to authenticated
using (public.has_branch_role(branch_id,array['owner','admin']::public.app_role[]))
with check (public.has_branch_role(branch_id,array['owner','admin']::public.app_role[]));
create policy "stock_movements_read_member" on public.stock_movements for select to authenticated using (public.is_branch_member(branch_id));
create policy "customers_read_member" on public.customers for select to authenticated using (exists(select 1 from public.branches b where b.organization_id=customers.organization_id and public.is_branch_member(b.id)));
create policy "customers_write_admin" on public.customers for all to authenticated
using (exists(select 1 from public.branches b where b.organization_id=customers.organization_id and public.has_branch_role(b.id,array['owner','admin']::public.app_role[])))
with check (exists(select 1 from public.branches b where b.organization_id=customers.organization_id and public.has_branch_role(b.id,array['owner','admin']::public.app_role[])));
create policy "suppliers_read_member" on public.suppliers for select to authenticated using (exists(select 1 from public.branches b where b.organization_id=suppliers.organization_id and public.is_branch_member(b.id)));
create policy "suppliers_write_admin" on public.suppliers for all to authenticated
using (exists(select 1 from public.branches b where b.organization_id=suppliers.organization_id and public.has_branch_role(b.id,array['owner','admin']::public.app_role[])))
with check (exists(select 1 from public.branches b where b.organization_id=suppliers.organization_id and public.has_branch_role(b.id,array['owner','admin']::public.app_role[])));
create policy "sales_read_member" on public.sales for select to authenticated using (public.is_branch_member(branch_id));
create policy "sale_items_read_member" on public.sale_items for select to authenticated
using (exists(select 1 from public.sales s where s.id=sale_id and public.is_branch_member(s.branch_id)));
create policy "payments_read_member" on public.payments for select to authenticated using (public.is_branch_member(branch_id));
create policy "audit_read_admin" on public.audit_logs for select to authenticated using (branch_id is null or public.has_branch_role(branch_id,array['owner','admin']::public.app_role[]));
create policy "customer_ledger_read_member" on public.customer_ledger for select to authenticated using (public.is_branch_member(branch_id));
create policy "po_read_member" on public.purchase_orders for select to authenticated using (public.is_branch_member(branch_id));
create policy "po_write_admin" on public.purchase_orders for all to authenticated using (public.has_branch_role(branch_id,array['owner','admin']::public.app_role[])) with check (public.has_branch_role(branch_id,array['owner','admin']::public.app_role[]));
create policy "po_items_read_member" on public.purchase_order_items for select to authenticated using (exists(select 1 from public.purchase_orders p where p.id=purchase_order_id and public.is_branch_member(p.branch_id)));
create policy "goods_receipts_read_member" on public.goods_receipts for select to authenticated using (public.is_branch_member(branch_id));
create policy "goods_receipts_write_admin" on public.goods_receipts for all to authenticated using (public.has_branch_role(branch_id,array['owner','admin']::public.app_role[])) with check (public.has_branch_role(branch_id,array['owner','admin']::public.app_role[]));
create policy "goods_receipt_items_read_member" on public.goods_receipt_items for select to authenticated using (exists(select 1 from public.goods_receipts g where g.id=goods_receipt_id and public.is_branch_member(g.branch_id)));
create policy "supplier_ledger_read_member" on public.supplier_ledger for select to authenticated using (public.is_branch_member(branch_id));
create policy "stock_transfers_read_member" on public.stock_transfers for select to authenticated using (public.is_branch_member(from_branch_id) or public.is_branch_member(to_branch_id));
create policy "stock_transfers_write_admin" on public.stock_transfers for all to authenticated using (public.has_branch_role(from_branch_id,array['owner','admin']::public.app_role[])) with check (public.has_branch_role(from_branch_id,array['owner','admin']::public.app_role[]));
create policy "stock_transfer_items_read_member" on public.stock_transfer_items for select to authenticated using (exists(select 1 from public.stock_transfers t where t.id=transfer_id and (public.is_branch_member(t.from_branch_id) or public.is_branch_member(t.to_branch_id))));
create policy "expenses_read_member" on public.expenses for select to authenticated using (public.is_branch_member(branch_id));
create policy "expenses_write_admin" on public.expenses for all to authenticated using (public.has_branch_role(branch_id,array['owner','admin']::public.app_role[])) with check (public.has_branch_role(branch_id,array['owner','admin']::public.app_role[]));
create policy "employees_read_admin" on public.employees for select to authenticated using (public.has_branch_role(branch_id,array['owner','admin']::public.app_role[]));
create policy "employees_write_owner" on public.employees for all to authenticated using (public.has_branch_role(branch_id,array['owner']::public.app_role[])) with check (public.has_branch_role(branch_id,array['owner']::public.app_role[]));
create policy "attendance_read_admin" on public.attendance for select to authenticated using (exists(select 1 from public.employees e where e.id=employee_id and public.has_branch_role(e.branch_id,array['owner','admin']::public.app_role[])));
create policy "payroll_read_owner" on public.payroll_runs for select to authenticated using (public.has_branch_role(branch_id,array['owner']::public.app_role[]));
create policy "payroll_write_owner" on public.payroll_runs for all to authenticated using (public.has_branch_role(branch_id,array['owner']::public.app_role[])) with check (public.has_branch_role(branch_id,array['owner']::public.app_role[]));
create policy "payroll_items_read_owner" on public.payroll_items for select to authenticated using (exists(select 1 from public.payroll_runs r where r.id=payroll_run_id and public.has_branch_role(r.branch_id,array['owner']::public.app_role[])));
create policy "settings_read_member" on public.store_settings for select to authenticated using (exists(select 1 from public.branches b where b.organization_id=store_settings.organization_id and public.is_branch_member(b.id)));
create policy "settings_write_owner" on public.store_settings for all to authenticated using (exists(select 1 from public.branches b where b.organization_id=store_settings.organization_id and public.has_branch_role(b.id,array['owner']::public.app_role[]))) with check (exists(select 1 from public.branches b where b.organization_id=store_settings.organization_id and public.has_branch_role(b.id,array['owner']::public.app_role[])));

-- Explicit grants: all writes are controlled by both grants and RLS.
revoke all on all tables in schema public from anon, authenticated;
grant select on public.organizations,public.branches,public.profiles,public.branch_memberships,public.products,public.inventory,public.stock_movements,public.customers,public.suppliers,public.sales,public.sale_items,public.payments,public.audit_logs,public.customer_ledger,public.purchase_orders,public.purchase_order_items,public.goods_receipts,public.goods_receipt_items,public.supplier_ledger,public.stock_transfers,public.stock_transfer_items,public.expenses,public.employees,public.attendance,public.payroll_runs,public.payroll_items,public.store_settings to authenticated;
grant update on public.profiles to authenticated;
grant insert,update on public.products,public.inventory,public.customers,public.suppliers,public.purchase_orders,public.goods_receipts,public.stock_transfers,public.expenses,public.employees,public.attendance,public.payroll_runs,public.payroll_items,public.store_settings to authenticated;
grant usage,select on all sequences in schema public to authenticated;

-- Atomic/idempotent checkout. The browser never directly inserts sales or edits stock for a sale.
create or replace function public.checkout_sale(
  p_branch_id uuid,
  p_client_order_id uuid,
  p_payment_method public.payment_method,
  p_items jsonb
) returns uuid language plpgsql security definer set search_path = '' as $$
declare
  v_org uuid;
  v_sale_id uuid;
  v_subtotal numeric(14,2) := 0;
  v_item jsonb;
  v_product public.products%rowtype;
  v_qty numeric(14,3);
  v_price numeric(14,2);
  v_stock numeric(14,3);
  v_method public.payment_method;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if not public.is_branch_member(p_branch_id) then raise exception 'You are not assigned to this branch'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items)=0 then raise exception 'Sale must contain at least one item'; end if;
  if (select count(distinct value->>'product_id') from jsonb_array_elements(p_items)) <> jsonb_array_length(p_items) then
    raise exception 'Duplicate product lines are not allowed; combine quantities per product';
  end if;
  v_org := public.organization_for_branch(p_branch_id);
  v_method := p_payment_method;

  select id into v_sale_id from public.sales where branch_id=p_branch_id and client_order_id=p_client_order_id;
  if v_sale_id is not null then return v_sale_id; end if;

  -- Validate every item, then lock stock rows in deterministic product-id order.
  for v_item in select value from jsonb_array_elements(p_items) order by value->>'product_id' loop
    if not (v_item ? 'product_id' and v_item ? 'quantity' and v_item ? 'unit_price') then
      raise exception 'Invalid sale item';
    end if;
    v_qty := (v_item->>'quantity')::numeric;
    v_price := (v_item->>'unit_price')::numeric;
    if v_qty <= 0 or v_price < 0 then raise exception 'Invalid quantity or price'; end if;
    select * into v_product from public.products where id=(v_item->>'product_id')::uuid and organization_id=v_org and active for share;
    if not found then raise exception 'Product not found or inactive'; end if;
    select quantity_on_hand into v_stock from public.inventory where branch_id=p_branch_id and product_id=v_product.id for update;
    if not found then raise exception 'Product has no inventory record for this branch: %',v_product.name; end if;
    if v_stock < v_qty then raise exception 'Insufficient stock for % (available %, requested %)',v_product.name,v_stock,v_qty; end if;
    v_subtotal := v_subtotal + round(v_qty*v_price,2);
  end loop;

  insert into public.sales(organization_id,branch_id,client_order_id,subtotal,tax_amount,total,payment_method,created_by)
  values(v_org,p_branch_id,p_client_order_id,v_subtotal,0,v_subtotal,v_method,auth.uid()) returning id into v_sale_id;

  for v_item in select value from jsonb_array_elements(p_items) order by value->>'product_id' loop
    v_qty := (v_item->>'quantity')::numeric; v_price := (v_item->>'unit_price')::numeric;
    select * into v_product from public.products where id=(v_item->>'product_id')::uuid and organization_id=v_org for share;
    update public.inventory set quantity_on_hand=quantity_on_hand-v_qty,updated_at=now()
      where branch_id=p_branch_id and product_id=v_product.id;
    insert into public.sale_items(sale_id,product_id,sku_snapshot,name_snapshot,unit_snapshot,quantity,unit_price,unit_cost)
      values(v_sale_id,v_product.id,v_product.sku,v_product.name,v_product.unit,v_qty,v_price,v_product.cost_price);
    insert into public.stock_movements(organization_id,branch_id,product_id,movement_type,quantity_delta,reference_type,reference_id,actor_id)
      values(v_org,p_branch_id,v_product.id,'sale',-v_qty,'sale',v_sale_id,auth.uid());
  end loop;
  insert into public.payments(organization_id,branch_id,sale_id,direction,method,amount,status,created_by)
    values(v_org,p_branch_id,v_sale_id,'incoming',v_method,v_subtotal,'recorded',auth.uid());
  insert into public.audit_logs(organization_id,branch_id,actor_id,action,entity_type,entity_id,details)
    values(v_org,p_branch_id,auth.uid(),'checkout','sale',v_sale_id::text,jsonb_build_object('client_order_id',p_client_order_id,'total',v_subtotal,'item_count',jsonb_array_length(p_items)));
  return v_sale_id;
end;
$$;
revoke all on function public.checkout_sale(uuid,uuid,public.payment_method,jsonb) from public, anon;
grant execute on function public.checkout_sale(uuid,uuid,public.payment_method,jsonb) to authenticated;

-- Seed/setup guide creates first organization, branch, owner membership, and settings manually after first Auth user exists.
